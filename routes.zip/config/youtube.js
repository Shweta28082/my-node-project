const { google } = require("googleapis");
const credentials = require("../config/credentials"); // Path to your credentials.json

// OAuth2 client setup for YouTube API
const oauth2Client = new google.auth.OAuth2(
  credentials.web.client_id,
  credentials.web.client_secret,
  credentials.web.redirect_uris[0] // Ensure this matches your Google app setup
);

// Function to generate the YouTube authentication URL
function getAuthUrl() {
  return oauth2Client.generateAuthUrl({
    access_type: "offline", // Offline access to get refresh token
    scope: ["https://www.googleapis.com/auth/youtube.upload"], // YouTube upload scope
  });
}

// Function to get access token after user authorization
async function getAccessToken(code) {
  try {
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);
    console.log("Access token retrieved:", tokens);
    return tokens; // Return tokens to be used in your app
  } catch (err) {
    console.error("Error retrieving access token:", err.message);
    throw err; // Propagate error for the caller to handle
  }
}

// Export OAuth2 client and functions
module.exports = { oauth2Client, getAuthUrl, getAccessToken };
