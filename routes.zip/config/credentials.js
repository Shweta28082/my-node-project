// credentials.js
const { google } = require("googleapis");
const fs = require("fs");

// Credentials object
const credentials = {
  web: {
    client_id:
      "542597503461-khnhdequlg5sc09scokrdios6m1btjr7.apps.googleusercontent.com",
    project_id: "react-oauth-signup",
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_secret: "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",
    redirect_uris: ["http://localhost:5000/auth/google/callback"],
    javascript_origins: ["http://localhost:3000"],
  },
};

// Set up OAuth2 client
const oauth2Client = new google.auth.OAuth2(
  credentials.web.client_id,
  credentials.web.client_secret,
  credentials.web.redirect_uris[0]
);

// Function to generate authorization URL
const getAuthUrl = () => {
  const authUrl = oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: "https://www.googleapis.com/auth/youtube.upload", // Permissions for uploading videos
  });
  console.log("Authorize this app by visiting this URL:", authUrl);
  return authUrl;
};

// Function to exchange the authorization code for tokens
const getTokens = async (code) => {
  try {
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);
    console.log("Tokens received:", tokens);
    return tokens;
  } catch (error) {
    console.error("Error retrieving tokens:", error);
    throw error;
  }
};

// Function to upload video to YouTube
const uploadVideo = async (
  videoPath,
  title,
  description,
  privacyStatus = "public"
) => {
  try {
    const youtube = google.youtube({ version: "v3", auth: oauth2Client });
    const response = await youtube.videos.insert({
      part: "snippet,status",
      requestBody: {
        snippet: { title, description },
        status: { privacyStatus },
      },
      media: {
        body: fs.createReadStream(videoPath),
      },
    });
    console.log("Video uploaded successfully:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error uploading video:", error);
    throw error;
  }
};

// Export functions and OAuth client
module.exports = {
  getAuthUrl,
  getTokens,
  uploadVideo,
  oauth2Client,
};
