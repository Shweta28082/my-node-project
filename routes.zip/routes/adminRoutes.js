const {
  getPendingVideos,
  approveAndUploadVideo,
} = require("../controllers/adminController");

const express = require("express");
const router = express.Router();

// Define routes
router.get("/pending-videos", getPendingVideos);
router.post("/update-approval", approveAndUploadVideo);

module.exports = router;
