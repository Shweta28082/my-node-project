const db = require("../config/db");
const path = require("path");

exports.createProfile = (req, res) => {
  const { name, email, bio, phone } = req.body;

  // Log the incoming request body and files
  console.log("Request body:", req.body);
  console.log("Uploaded files:", req.files);

  // Generate file paths for photos
  const photoPaths = req.files["photos"]
    ? req.files["photos"].map((file) =>
        path.join("uploads/photos", file.filename)
      )
    : [];

  // Generate file path for video
  const videoPath =
    req.files["video"] && req.files["video"][0]
      ? path.join("uploads/videos", req.files["video"][0].filename)
      : null;

  // SQL query to insert data into the users table
  const sql = `
    UPDATE users SET 
      bio = ?, 
      phone = ?, 
      photos = ?, 
      video_url = ?, 
      approval_status = 'pending'
    WHERE email = ?`;

  // Log SQL query for debugging
  console.log("SQL Query:", sql);
  console.log("Values:", [
    bio,
    phone,
    JSON.stringify(photoPaths),
    videoPath,
    email,
  ]);

  // Executing the query
  db.query(
    sql,
    [bio, phone, JSON.stringify(photoPaths), videoPath, email],
    (err, result) => {
      if (err) {
        console.error("Error updating profile:", err);
        return res.status(500).json({ message: "Error creating profile" });
      }
      console.log("Profile updated successfully:", result);
      res.json({
        message: "Profile created successfully",
      });
    }
  );
};
