const db = require("../config/db"); // Database connection
const { uploadVideo } = require("../config/credentials"); // Upload function

// Fetch pending videos
const getPendingVideos = (req, res) => {
  const sqlQuery = "SELECT * FROM users WHERE approval_status = 'pending'";

  db.query(sqlQuery, (err, results) => {
    if (err) {
      console.error("Error fetching pending videos:", err);
      return res.status(500).json({ error: "Error fetching pending videos." });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: "No pending videos found." });
    }

    res.json(results); // Returning list of pending videos
  });
};

// Approve and upload video
const approveAndUploadVideo = (req, res) => {
  const { profileId, videoPath } = req.body;

  // Validate input data
  if (!profileId || !videoPath) {
    return res
      .status(400)
      .json({ error: "Profile ID and video path are required." });
  }

  // Update approval status in the database
  const updateQuery =
    "UPDATE users SET approval_status = 'approved' WHERE id = ?";

  db.query(updateQuery, [profileId], (err, results) => {
    if (err) {
      console.error("Error updating approval status:", err);
      return res.status(500).json({ error: "Error updating approval status." });
    }

    if (results.affectedRows === 0) {
      return res
        .status(404)
        .json({ error: "No profile found with the given ID." });
    }

    // Upload video to YouTube
    uploadVideo(videoPath, "Approved Video", "This is an approved video.")
      .then((videoData) => {
        // On success, send the YouTube video ID in the response
        res.json({
          message: "Video approved and uploaded successfully.",
          youtubeVideoId: videoData.id,
          youtubeLink: `https://www.youtube.com/watch?v=${videoData.id}`,
        });
      })
      .catch((err) => {
        console.error("Error uploading video:", err);
        res
          .status(500)
          .json({ error: "Video approved, but upload to YouTube failed." });
      });
  });
};

// Exporting the functions
module.exports = {
  getPendingVideos,
  approveAndUploadVideo,
};
