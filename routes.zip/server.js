const express = require("express");
const cors = require("cors");
const { OAuth2Client } = require("google-auth-library");
const db = require("./config/db");
require("dotenv").config();
const upload = require("./middleware/upload");
const profileController = require("./controllers/profileController");
const adminRoutes = require("./routes/adminRoutes"); // Ensure the correct path


const app = express();
const port = 5000;

app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());

// Register the admin routes under the '/api/admin' path
app.use("/api/admin", adminRoutes);

// Profile creation route
app.post("/api/profile", upload, profileController.createProfile);

// Google OAuth setup
const client = new OAuth2Client(
  process.env.CLIENT_ID,
  process.env.CLIENT_SECRET,
  "http://localhost:5000/auth/google/callback"
);

// Google OAuth routes
app.get("/auth/google", (req, res) => {
  const url = client.generateAuthUrl({
    access_type: "offline",
    scope: ["profile", "email"],
    redirect_uri: "http://localhost:5000/auth/google/callback",
  });
  res.redirect(url);
});

app.get("/auth/google/callback", async (req, res) => {
  try {
    const { tokens } = await client.getToken({
      code: req.query.code,
      redirect_uri: "http://localhost:5000/auth/google/callback",
    });
    client.setCredentials(tokens);

    const ticket = await client.verifyIdToken({
      idToken: tokens.id_token,
      audience: process.env.CLIENT_ID,
    });
    const payload = ticket.getPayload();
    const email = payload.email;
    const name = payload.name;

    db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
      if (err) return res.status(500).json({ error: "Database error" });

      if (results.length > 0) {
        res.redirect(`http://localhost:3000/home?message=User already exists!`);
      } else {
        db.query(
          "INSERT INTO users (name, email) VALUES (?, ?)",
          [name, email],
          (insertErr) => {
            if (insertErr)
              return res
                .status(500)
                .json({ error: "Database insertion error" });
            res.redirect(
              `http://localhost:3000/home?message=User registered successfully!`
            );
          }
        );
      }
    });
  } catch (error) {
    console.error("Google login error:", error);
    res.status(401).json({ message: "Invalid Google token" });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
