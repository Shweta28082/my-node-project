const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Ensure uploads directories exist
const ensureDirectoryExistence = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

// Configure multer storage for photos and videos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir =
      file.fieldname === "photos" ? "uploads/photos" : "uploads/videos";
    ensureDirectoryExistence(dir);
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

// File filter to allow specific image and video types
const fileFilter = (req, file, cb) => {
  const allowedImageTypes = ["image/jpeg", "image/png", "image/jpg"];
  const allowedVideoTypes = [
    "video/mp4",
    "video/x-msvideo",
    "video/avi",
    "video/quicktime",
  ];

  if (
    allowedImageTypes.includes(file.mimetype) ||
    allowedVideoTypes.includes(file.mimetype)
  ) {
    cb(null, true); // Allow file
  } else {
    cb(
      new Error(
        "Invalid file format. Please upload a JPG, PNG, MP4, AVI, or MOV file."
      ),
      false // Reject file
    );
  }
};

// Configure multer for handling multiple fields (photos array and single video)
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
}).fields([
  { name: "photos", maxCount: 10 }, // Allow up to 10 photos
  { name: "video", maxCount: 1 }, // Only 1 video
]);

module.exports = upload;
